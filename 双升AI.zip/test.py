from myutils import Num2Poker_seq

print(Num2Poker_seq([82, 22, 37, 90, 48, 15, 27, 31]))
print(Num2Poker_seq([82, 22, 37, 90, 48, 8, 46, 21]))


my_list = [1,3,5,6,2]

for num in reversed(my_list):
    print(num)

